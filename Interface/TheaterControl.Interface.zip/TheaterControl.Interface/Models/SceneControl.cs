﻿
namespace TheaterControl.Interface.Models
{
    public enum SceneControl
    {
        Next,
        Previous,
        Play,
        Stop,
        Emergency,
        RequestScenes,
        ScenesChanged
    }
}
