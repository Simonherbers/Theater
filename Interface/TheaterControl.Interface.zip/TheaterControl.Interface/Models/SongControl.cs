﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TheaterControl.Interface.Models
{
    public enum SongControl
    {
        PrevSong,
        RunBack,
        Pause,
        RunForward,
        NextSong
    }
}
